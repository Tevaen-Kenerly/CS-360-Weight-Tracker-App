package com.example.tevaenkenerlyweighttracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var enableButton: Button
    private lateinit var skipButton: Button

    private val SMS_PERMISSION = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        status = findViewById(R.id.textSMSStatus)
        enableButton = findViewById(R.id.buttonEnableSMS)
        skipButton = findViewById(R.id.buttonSkipSMS)

        enableButton.setOnClickListener {

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION
                )

            } else {

                sendTestSMS()

            }
        }

        skipButton.setOnClickListener {

            status.text = "SMS notifications disabled."

        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {

            sendTestSMS()

        } else {

            status.text = "Permission Denied"

        }
    }

    private fun sendTestSMS() {

        try {

            val smsManager = SmsManager.getDefault()

            smsManager.sendTextMessage(
                "5555555555",
                null,
                "Congratulations! You reached your goal weight!",
                null,
                null
            )

            status.text = "SMS Sent!"

        } catch (e: Exception) {

            Toast.makeText(this, e.message, Toast.LENGTH_LONG).show()

        }
    }
}