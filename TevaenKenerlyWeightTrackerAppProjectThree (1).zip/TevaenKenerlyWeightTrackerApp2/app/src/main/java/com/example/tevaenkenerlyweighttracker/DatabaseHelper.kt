package com.example.tevaenkenerlyweighttracker

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {

        private const val DATABASE_NAME = "WeightTracker.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_USERS = "users"
        const val USER_ID = "id"
        const val USERNAME = "username"
        const val PASSWORD = "password"

        const val TABLE_WEIGHTS = "weights"
        const val WEIGHT_ID = "id"
        const val DATE = "date"
        const val WEIGHT = "weight"
    }

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            """
            CREATE TABLE $TABLE_USERS(
                $USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $USERNAME TEXT UNIQUE,
                $PASSWORD TEXT
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE $TABLE_WEIGHTS(
                $WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $DATE TEXT,
                $WEIGHT TEXT
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")

        onCreate(db)
    }

    fun insertUser(username: String, password: String): Boolean {

        val db = writableDatabase

        val values = ContentValues()
        values.put(USERNAME, username)
        values.put(PASSWORD, password)

        return db.insert(TABLE_USERS, null, values) != -1L
    }

    fun addUser(username: String, password: String): Boolean {
        return insertUser(username, password)
    }

    fun checkUser(username: String, password: String): Boolean {

        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $USERNAME=? AND $PASSWORD=?",
            arrayOf(username, password)
        )

        val exists = cursor.count > 0

        cursor.close()

        return exists
    }

    fun addWeight(date: String, weight: String): Boolean {

        val values = ContentValues()
        values.put(DATE, date)
        values.put(WEIGHT, weight)

        return writableDatabase.insert(TABLE_WEIGHTS, null, values) != -1L
    }

    fun getWeights(): Cursor {

        return readableDatabase.rawQuery(
            "SELECT * FROM $TABLE_WEIGHTS",
            null
        )
    }

    fun updateWeight(id: Int, date: String, weight: String): Boolean {

        val values = ContentValues()
        values.put(DATE, date)
        values.put(WEIGHT, weight)

        return writableDatabase.update(
            TABLE_WEIGHTS,
            values,
            "$WEIGHT_ID=?",
            arrayOf(id.toString())
        ) > 0
    }

    fun deleteWeight(id: Int) {

        writableDatabase.delete(
            TABLE_WEIGHTS,
            "$WEIGHT_ID=?",
            arrayOf(id.toString())
        )
    }
}