package com.example.tevaenkenerlyweighttracker

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class WeightActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper

    private lateinit var tableWeights: TableLayout
    private lateinit var editDate: EditText
    private lateinit var editWeight: EditText
    private lateinit var buttonAddWeight: Button

    private var selectedWeightId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_grid)

        databaseHelper = DatabaseHelper(this)

        tableWeights = findViewById(R.id.tableWeights)
        editDate = findViewById(R.id.editDate)
        editWeight = findViewById(R.id.editWeight)
        buttonAddWeight = findViewById(R.id.buttonAddWeight)

        loadWeights()

        buttonAddWeight.setOnClickListener {

            val date = editDate.text.toString()
            val weight = editWeight.text.toString()

            if (date.isEmpty() || weight.isEmpty()) {
                Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedWeightId == -1) {

                databaseHelper.addWeight(date, weight)

                Toast.makeText(this, "Weight Added", Toast.LENGTH_SHORT).show()

            } else {

                databaseHelper.updateWeight(selectedWeightId, date, weight)

                Toast.makeText(this, "Weight Updated", Toast.LENGTH_SHORT).show()

                selectedWeightId = -1
            }

            editDate.text.clear()
            editWeight.text.clear()

            loadWeights()

            if (weight.toDoubleOrNull() != null && weight.toDouble() <= 180.0) {
                startActivity(Intent(this, SmsActivity::class.java))
            }
        }
    }

    private fun loadWeights() {

        while (tableWeights.childCount > 1) {
            tableWeights.removeViewAt(1)
        }

        val cursor: Cursor = databaseHelper.getWeights()

        while (cursor.moveToNext()) {

            val id = cursor.getInt(0)
            val date = cursor.getString(1)
            val weight = cursor.getString(2)

            val row = TableRow(this)

            val dateView = TextView(this)
            dateView.text = date

            val weightView = TextView(this)
            weightView.text = weight
            row.setOnClickListener {

                editDate.setText(date)

                editWeight.setText(weight)

                selectedWeightId = id

                Toast.makeText(this, "Editing entry", Toast.LENGTH_SHORT).show()
            }
            val deleteButton = Button(this)
            deleteButton.text = "Delete"

            deleteButton.setOnClickListener {
                databaseHelper.deleteWeight(id)
                loadWeights()
            }

            row.addView(dateView)
            row.addView(weightView)
            row.addView(deleteButton)

            tableWeights.addView(row)
        }

        cursor.close()
    }
}