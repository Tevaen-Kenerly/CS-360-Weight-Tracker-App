package com.example.tevaenkenerlyweighttracker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        databaseHelper = DatabaseHelper(this)

        val username = findViewById<EditText>(R.id.editUsername)
        val password = findViewById<EditText>(R.id.editPassword)

        val loginButton = findViewById<Button>(R.id.buttonLogin)
        val createButton = findViewById<Button>(R.id.buttonCreateAccount)

        // Create Account
        createButton.setOnClickListener {

            val user = username.text.toString()
            val pass = password.text.toString()

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
            } else {

                val success = databaseHelper.addUser(user, pass)

                if (success) {
                    Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Login
        loginButton.setOnClickListener {

            val user = username.text.toString()
            val pass = password.text.toString()

            if (databaseHelper.checkUser(user, pass)) {

                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()

                val intent = Intent(this, WeightActivity::class.java)
                startActivity(intent)
                finish()

            } else {

                Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show()

            }
        }

    }
}